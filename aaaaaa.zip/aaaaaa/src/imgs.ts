export default {
  yellowBubble: require("../assets/yellow/Dook.png"),
  pinkBubble: require("../assets/pink/Dook.png"),
  purpleBubble: require("../assets/purple/Dook.png"),
};
